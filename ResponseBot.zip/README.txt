 -- INTRODUCTION --
Hello, and welcome to this README.txt file! I'd write a bunch of stuff here, but I cannot be arsed right now. Point is that this bot is a small one, written due to a demand for something like this for a few people. All it does is respond to specific phrases, specific people, or in specific channels at a specific chance, or any combination of that. All data is loaded from a single .JSON file for easy editing, and can be reloaded on the fly with the !reload command. I wrote this while very tired, with little time to test, so if you find and issues or bugs, I'd be happy to hear about them in the ISSUES section of this projects GitHub page. 

 -- INSTALLATION AND RUNNING THE BOT -- 
Installing the not-so-compact bot is as easy as dragging the files into a fitting directory, and putting your bot token into the bot token file found at ResponseBot/data/bottoken.botproperty. Running the bot requires a bit of wizardry, since it runs on .NET Core. On a Linux server it should be fairly easy, since Dotnet is most likely already installed. Simply type in "dotnet <path to ResponseBot.dll>" and you should be golden.

I'm gonna be honest, I don't know how to run a .NET Core program on Windows, ironically enough. If somebody knows this I'd be happy to hear, as well as add it in here.

 -- ADDING NEW PHRASES --
Phrases are stored in a JSON file at ResponseBot/data/phrases.json, and can from there be quite easily edited. JSON property names should be fairly self explanatory as well. If you've edited the file while the bot is running, you can simply write !reload to reload the file. I suggest using a JSON formatter and validator, or alternatively an editor to edit the text in the file, in order to avoid errors and mistakes. This one is quite a neat little validator: https://jsonformatter.curiousconcept.com/

Something something licensing..